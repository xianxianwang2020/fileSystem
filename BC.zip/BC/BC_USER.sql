USE BC
SELECT * FROM [dbo].[bc_user]
ORDER BY ID


TRUNCATE TABLE [dbo].[bc_user]